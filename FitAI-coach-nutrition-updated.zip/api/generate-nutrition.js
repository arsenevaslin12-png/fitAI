"use strict";

function getCreateClient() {
  try {
    const mod = require("@supabase/supabase-js");
    return typeof mod.createClient === "function" ? mod.createClient : null;
  } catch {
    return null;
  }
}
const {
  DEFAULT_MODEL,
  FALLBACK_MODEL,
  extractJson,
  callGeminiText,
  normalizeGeminiError
} = require("./_gemini");

const GEMINI_TIMEOUT_MS = 3200;
const rateLimitBuckets = new Map();

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type, authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

function sendJson(res, status, payload) {
  if (res.writableEnded) return;
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch { return {}; }
  }
  return req.body;
}

function getIp(req) {
  const xfwd = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return xfwd || req.socket?.remoteAddress || "unknown";
}

function checkRateLimit(bucket, key, limit = 10, windowMs = 60_000) {
  const now = Date.now();
  const bucketKey = `${bucket}:${key}`;
  const prev = rateLimitBuckets.get(bucketKey) || [];
  const recent = prev.filter((ts) => now - ts < windowMs);
  if (recent.length >= limit) {
    rateLimitBuckets.set(bucketKey, recent);
    const retryAfterSec = Math.max(1, Math.ceil((windowMs - (now - recent[0])) / 1000));
    return { ok: false, retryAfterSec };
  }
  recent.push(now);
  rateLimitBuckets.set(bucketKey, recent);
  return { ok: true };
}

function pickAnonKey() {
  return (
    String(process.env.SUPABASE_ANON_KEY || "").trim() ||
    String(process.env.SUPABASE_PUBLISHABLE_KEY || "").trim() ||
    String(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "").trim() ||
    String(process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || "").trim() ||
    ""
  );
}

function sanitizeValue(value, fallback = "") {
  return String(value == null ? fallback : value)
    .replace(/[<>]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeGoal(value) {
  const v = sanitizeValue(value, "maintenance").toLowerCase();
  if (["perte_de_poids", "cut", "seche"].includes(v)) return "perte_de_poids";
  if (["prise_de_masse", "bulk", "masse"].includes(v)) return "prise_de_masse";
  return "maintenance";
}

function normalizeActivity(value) {
  const v = sanitizeValue(value, "moderate").toLowerCase();
  if (["low", "faible"].includes(v)) return "low";
  if (["high", "elevee", "élevée"].includes(v)) return "high";
  return "moderate";
}

function clamp(num, min, max) {
  const value = Number(num);
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.min(max, value));
}

function validateNutrition(raw) {
  if (!raw || typeof raw !== "object") return null;
  const nutrition = {
    calories: Math.round(clamp(raw.calories, 1200, 4500)),
    protein: Math.round(clamp(raw.protein, 70, 320)),
    carbs: Math.round(clamp(raw.carbs, 50, 550)),
    fats: Math.round(clamp(raw.fats, 30, 180)),
    notes: sanitizeValue(raw.notes, "Plan nutrition généré automatiquement.") || "Plan nutrition généré automatiquement."
  };
  return nutrition;
}

function normalizeMeal(meal, idx, nutrition) {
  const fallbackNames = ["Petit déjeuner", "Déjeuner", "Collation", "Dîner"];
  if (!meal || typeof meal !== "object") {
    return {
      name: fallbackNames[idx] || `Repas ${idx + 1}`,
      time: ["08:00", "12:30", "16:30", "20:00"][idx] || "",
      calories: Math.round(nutrition.calories / 4),
      protein: Math.round(nutrition.protein / 4),
      items: ["Source de protéines", "Féculent", "Légumes"]
    };
  }
  const items = Array.isArray(meal.items)
    ? meal.items.map((item) => sanitizeValue(item)).filter(Boolean).slice(0, 6)
    : [];
  return {
    name: sanitizeValue(meal.name, fallbackNames[idx] || `Repas ${idx + 1}`),
    time: sanitizeValue(meal.time, ["08:00", "12:30", "16:30", "20:00"][idx] || ""),
    calories: Math.round(clamp(meal.calories, 120, 1600)),
    protein: Math.round(clamp(meal.protein, 10, 90)),
    items: items.length ? items : ["Source de protéines", "Légumes", "Féculent adapté"]
  };
}

function buildFallbackNutrition(weight = 75, goal = "maintenance", activity = "moderate") {
  const activityFactor = activity === "high" ? 34 : activity === "low" ? 28 : 31;
  const base = Math.round(weight * activityFactor);
  const calories = goal === "perte_de_poids" ? base - 350 : goal === "prise_de_masse" ? base + 250 : base;
  const protein = Math.round(weight * (goal === "perte_de_poids" ? 2.1 : 1.8));
  const fats = Math.round(weight * 0.9);
  const carbs = Math.max(100, Math.round((calories - (protein * 4 + fats * 9)) / 4));
  return {
    calories,
    protein,
    carbs,
    fats,
    notes: goal === "perte_de_poids"
      ? "Priorité aux protéines, aux fibres et à une bonne satiété sur la journée."
      : goal === "prise_de_masse"
        ? "Répartissez les glucides autour de l'entraînement pour mieux performer et récupérer."
        : "Visez l'équilibre: protéines régulières, glucides utiles et lipides modérés."
  };
}

function buildFallbackPlan(nutrition, goal = "maintenance") {
  const isCut = goal === "perte_de_poids";
  const isBulk = goal === "prise_de_masse";
  const breakfastPct = isBulk ? 0.24 : 0.22;
  const lunchPct = 0.33;
  const snackPct = isBulk ? 0.16 : 0.13;
  const dinnerPct = 1 - breakfastPct - lunchPct - snackPct;

  const meals = [
    {
      name: "Petit déjeuner",
      time: "08:00",
      calories: Math.round(nutrition.calories * breakfastPct),
      protein: Math.round(nutrition.protein * 0.25),
      items: ["Skyr ou fromage blanc", "Flocons d'avoine", "Fruit", "Quelques oléagineux"]
    },
    {
      name: "Déjeuner",
      time: "12:30",
      calories: Math.round(nutrition.calories * lunchPct),
      protein: Math.round(nutrition.protein * 0.32),
      items: ["Poulet / dinde / tofu", "Riz ou pommes de terre", "Légumes", "Huile d'olive"]
    },
    {
      name: "Collation",
      time: "16:30",
      calories: Math.round(nutrition.calories * snackPct),
      protein: Math.round(nutrition.protein * 0.16),
      items: ["Yaourt grec ou whey", "Fruit", isBulk ? "Pain complet ou galettes de riz" : "Option légère selon faim"]
    },
    {
      name: "Dîner",
      time: "20:00",
      calories: Math.round(nutrition.calories * dinnerPct),
      protein: Math.round(nutrition.protein * 0.27),
      items: [isCut ? "Poisson maigre / œufs" : "Saumon / steak 5% / œufs", "Légumes cuits", isCut ? "Féculent modéré" : "Féculent selon dépense"]
    }
  ];

  return {
    title: "Plan nutrition du jour",
    hydration_liters: isBulk ? 2.8 : isCut ? 2.5 : 2.3,
    notes: isCut
      ? "Cherchez la satiété avec des protéines élevées et des légumes à chaque repas."
      : isBulk
        ? "Répartissez l'énergie sur 4 prises pour faciliter le surplus calorique."
        : "Restez régulier sur les protéines et ajustez vos glucides selon votre activité du jour.",
    meals
  };
}

function validatePlan(raw, nutrition, goal) {
  const candidate = raw && typeof raw === "object" ? raw : {};
  const rawMeals = Array.isArray(candidate.meals) ? candidate.meals.slice(0, 4) : [];
  const plan = {
    title: sanitizeValue(candidate.title, "Plan nutrition du jour") || "Plan nutrition du jour",
    hydration_liters: Number.isFinite(Number(candidate.hydration_liters))
      ? clamp(candidate.hydration_liters, 1.5, 4)
      : buildFallbackPlan(nutrition, goal).hydration_liters,
    notes: sanitizeValue(candidate.notes, nutrition.notes) || nutrition.notes,
    meals: rawMeals.map((meal, idx) => normalizeMeal(meal, idx, nutrition))
  };
  if (plan.meals.length < 3) {
    return buildFallbackPlan(nutrition, goal);
  }
  return plan;
}

function buildPrompt(profile) {
  return `Tu es un nutritionniste sportif. Tu réponds UNIQUEMENT en JSON valide, sans markdown, sans texte autour.

Objectif: créer des macros quotidiennes cohérentes + un plan de repas simple à suivre.

CONTRAINTES:
- Réponse brève, crédible, actionnable.
- Les calories, protéines, glucides et lipides doivent être cohérents entre eux.
- 4 repas maximum.
- Pas d'aliments exotiques ou compliqués.
- Français uniquement.

FORMAT UNIQUE:
{
  "calories": 2400,
  "protein": 160,
  "carbs": 280,
  "fats": 70,
  "notes": "...",
  "hydration_liters": 2.4,
  "meals": [
    {"name":"Petit déjeuner","time":"08:00","items":["...","..."],"calories":550,"protein":35},
    {"name":"Déjeuner","time":"12:30","items":["...","..."],"calories":750,"protein":45},
    {"name":"Collation","time":"16:30","items":["...","..."],"calories":300,"protein":25},
    {"name":"Dîner","time":"20:00","items":["...","..."],"calories":800,"protein":45}
  ]
}

PROFIL:
${JSON.stringify(profile)}`;
}

async function callGeminiNutrition(apiKey, profile) {
  const result = await callGeminiText({
    apiKey,
    prompt: buildPrompt(profile),
    temperature: 0.35,
    maxOutputTokens: 700,
    timeoutMs: GEMINI_TIMEOUT_MS,
    retries: 1
  });
  const parsed = extractJson(result.text) || {};
  const nutrition = validateNutrition(parsed) || buildFallbackNutrition(profile.weight, profile.goal, profile.activity_level);
  const plan = validatePlan(parsed, nutrition, profile.goal);
  return { nutrition, plan, model: result.model };
}

module.exports = async function handler(req, res) {
  setCors(res);
  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;

  if (req.method === "OPTIONS") {
    res.statusCode = 204;
    return res.end();
  }
  if (req.method !== "POST") {
    return sendJson(res, 405, { ok: false, error: "METHOD_NOT_ALLOWED", requestId });
  }

  const limit = checkRateLimit("generate-nutrition", getIp(req), 8, 60_000);
  if (!limit.ok) {
    res.setHeader("Retry-After", String(limit.retryAfterSec));
    return sendJson(res, 429, { ok: false, error: "RATE_LIMITED", requestId });
  }

  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return sendJson(res, 401, { ok: false, error: "UNAUTHORIZED", requestId });

  const SUPABASE_URL = String(process.env.SUPABASE_URL || "").trim().replace(/\/+$/, "");
  const ANON_KEY = pickAnonKey();
  if (!SUPABASE_URL || !ANON_KEY) {
    return sendJson(res, 500, {
      ok: false,
      error: "SERVER_MISCONFIG_SUPABASE",
      message: "Variables Supabase manquantes côté serveur.",
      requestId
    });
  }

  const body = parseBody(req);
  const goal = normalizeGoal(body.goal);
  const activity_level = normalizeActivity(body.activity_level);
  const apiKey = String(process.env.GEMINI_API_KEY || "").trim();

  try {
    const createClient = getCreateClient();
    if (typeof createClient !== "function") {
      return sendJson(res, 200, {
        ok: true,
        requestId,
        nutrition: buildFallbackNutrition(75, goal, activity_level),
        plan: buildFallbackPlan(buildFallbackNutrition(75, goal, activity_level), goal),
        hydration_liters: buildFallbackPlan(buildFallbackNutrition(75, goal, activity_level), goal).hydration_liters,
        fallback: true,
        error: "SUPABASE_CLIENT_UNAVAILABLE",
        error_code: "SUPABASE_CLIENT_UNAVAILABLE",
        model_default: DEFAULT_MODEL,
        model_fallback: FALLBACK_MODEL,
        saved: false
      });
    }
    const authClient = createClient(SUPABASE_URL, ANON_KEY, { auth: { persistSession: false } });
    const { data: authData, error: authError } = await authClient.auth.getUser(token);
    const userId = authData?.user?.id;
    if (authError || !userId) {
      return sendJson(res, 401, { ok: false, error: "INVALID_TOKEN", requestId });
    }

    const supabase = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false }
    });

    const { data: profileData } = await supabase
      .from("profiles")
      .select("weight")
      .eq("id", userId)
      .maybeSingle();

    const profile = {
      weight: Number(profileData?.weight || 75),
      goal,
      activity_level
    };

    const result = apiKey
      ? await callGeminiNutrition(apiKey, profile)
      : {
          nutrition: buildFallbackNutrition(profile.weight, goal, activity_level),
          plan: buildFallbackPlan(buildFallbackNutrition(profile.weight, goal, activity_level), goal),
          model: "fallback:no-key",
          fallback: true
        };

    const upsert = await supabase.from("nutrition_targets").upsert({
      user_id: userId,
      calories: result.nutrition.calories,
      protein: result.nutrition.protein,
      carbs: result.nutrition.carbs,
      fats: result.nutrition.fats,
      notes: result.nutrition.notes,
      updated_at: new Date().toISOString()
    }, { onConflict: "user_id" });

    if (upsert.error) {
      console.error("[generate-nutrition] upsert error:", upsert.error.message);
    }

    return sendJson(res, 200, {
      ok: true,
      requestId,
      nutrition: result.nutrition,
      plan: result.plan,
      hydration_liters: result.plan?.hydration_liters || null,
      fallback: !!result.fallback,
      model: result.model,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL,
      saved: !upsert.error
    });
  } catch (error) {
    const fallbackNutrition = buildFallbackNutrition(75, goal, activity_level);
    const fallbackPlan = buildFallbackPlan(fallbackNutrition, goal);
    const info = normalizeGeminiError(error);
    console.error("[generate-nutrition]", info.code, info.message.slice(0, 200));
    return sendJson(res, 200, {
      ok: true,
      requestId,
      nutrition: fallbackNutrition,
      plan: fallbackPlan,
      hydration_liters: fallbackPlan.hydration_liters,
      fallback: true,
      error: info.message,
      error_code: info.code,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL,
      saved: false
    });
  }
};
