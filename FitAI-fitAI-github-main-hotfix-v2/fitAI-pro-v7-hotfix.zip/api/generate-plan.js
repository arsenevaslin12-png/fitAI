"use strict";

const { createClient } = require("@supabase/supabase-js");
const {
  DEFAULT_MODEL,
  FALLBACK_MODEL,
  extractJson,
  callGeminiText,
  normalizeGeminiError
} = require("./_gemini");

const GEMINI_TIMEOUT_MS = 22000;

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type, authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

function sendJson(res, status, payload) {
  if (res.writableEnded) return;
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch { return {}; }
  }
  return req.body;
}

function validatePlan(raw) {
  if (!raw || !Array.isArray(raw.plan)) return null;
  const plan = raw.plan
    .map((row) => ({
      day: Number(row.day),
      workout_type: String(row.workout_type || "").trim(),
      intensity: String(row.intensity || "medium").trim().toLowerCase(),
      notes: String(row.notes || "").trim()
    }))
    .filter((row) => Number.isInteger(row.day) && row.day >= 1 && row.day <= 7 && row.workout_type);
  if (plan.length !== 7) return null;
  return plan.sort((a, b) => a.day - b.day);
}

function fallbackPlan(profile = {}) {
  const level = String(profile.level || "beginner").toLowerCase();
  const goal = String(profile.goal || "remise_en_forme").toLowerCase();
  const hard = level === "advanced" ? "hard" : "medium";
  const cardio = goal === "perte_de_poids" || goal === "endurance" ? "Cardio zone 2" : "Marche active + mobilité";
  return [
    { day: 1, workout_type: "Full body technique", intensity: "medium", notes: "3 à 4 mouvements de base, RPE 6-7" },
    { day: 2, workout_type: cardio, intensity: "easy", notes: "30 à 40 minutes" },
    { day: 3, workout_type: "Haut du corps", intensity: hard, notes: "Pousser + tirer, progression simple" },
    { day: 4, workout_type: "Recovery", intensity: "easy", notes: "Mobilité, gainage, marche" },
    { day: 5, workout_type: "Bas du corps", intensity: hard, notes: "Accent squat/hinge/fentes" },
    { day: 6, workout_type: goal === "force" ? "Technique + accessoires" : "Conditioning court", intensity: "medium", notes: "Volume contrôlé" },
    { day: 7, workout_type: "OFF", intensity: "easy", notes: "Repos complet ou 20 min de marche" }
  ];
}

function buildPrompt(profile) {
  return `Tu es un préparateur physique.
Génère un plan hebdomadaire réaliste en JSON strict.

RÈGLES:
- exactement 7 jours
- au moins 1 jour OFF ou recovery
- varie les séances, évite les répétitions inutiles
- adapte au niveau, à l'objectif, à la récupération et aux blessures
- ajoute une note courte utile par jour
- aucun markdown
- aucune phrase hors JSON

FORMAT UNIQUE:
{"plan":[{"day":1,"workout_type":"Full body","intensity":"medium","notes":"..."}]}

PROFIL:
${JSON.stringify(profile)}`;
}

async function callGemini(apiKey, profile) {
  const result = await callGeminiText({
    apiKey,
    prompt: buildPrompt(profile),
    temperature: 0.45,
    maxOutputTokens: 1000,
    timeoutMs: GEMINI_TIMEOUT_MS,
    retries: 1
  });
  const parsed = validatePlan(extractJson(result.text));
  if (!parsed) throw new Error("INVALID_PLAN_JSON");
  return { plan: parsed, model: result.model };
}

function getWeekStartDate() {
  const now = new Date();
  const day = now.getDay() || 7;
  const monday = new Date(now);
  monday.setDate(now.getDate() - day + 1);
  return monday.toISOString().slice(0, 10);
}

async function loadProfile(supabase, userId) {
  const { data } = await supabase
    .from("profiles")
    .select("weight,height")
    .eq("id", userId)
    .maybeSingle();
  return data || {};
}

module.exports = async function handler(req, res) {
  setCors(res);
  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;

  if (req.method === "OPTIONS") { res.statusCode = 204; return res.end(); }
  if (req.method !== "POST") return sendJson(res, 405, { ok: false, error: "METHOD_NOT_ALLOWED", requestId });

  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return sendJson(res, 401, { ok: false, error: "UNAUTHORIZED", requestId });

  const { GEMINI_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return sendJson(res, 500, { ok: false, error: "SERVER_MISCONFIG_SUPABASE", requestId });
  }

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
  const auth = await supabase.auth.getUser(token);
  const userId = auth?.data?.user?.id;
  if (!userId) return sendJson(res, 401, { ok: false, error: "INVALID_TOKEN", requestId });

  const body = parseBody(req);

  try {
    const profile = {
      ...(await loadProfile(supabase, userId)),
      goal: String(body.goal || body.profileOverrides?.goal || "remise_en_forme"),
      level: String(body.level || body.profileOverrides?.level || "beginner"),
      injuries: String(body.injuries || body.profileOverrides?.injuries || ""),
      recovery_score: Number(body.recovery_score || body.profileOverrides?.recovery_score || 0) || null,
      sleep_hours: Number(body.sleep_hours || body.profileOverrides?.sleep_hours || 0) || null
    };

    const ai = GEMINI_API_KEY
      ? await callGemini(GEMINI_API_KEY, profile)
      : { plan: fallbackPlan(profile), model: "fallback:no-key" };

    const weekStart = getWeekStartDate();

    await supabase.from("training_schedule").delete().eq("user_id", userId).eq("week_start_date", weekStart);
    const rows = ai.plan.map((r) => ({
      user_id: userId,
      week_start_date: weekStart,
      day_of_week: r.day,
      day: r.day,
      workout_type: r.workout_type,
      intensity: r.intensity,
      notes: r.notes,
      status: "planned"
    }));
    const insert = await supabase.from("training_schedule").insert(rows);
    if (insert.error) throw insert.error;

    return sendJson(res, 200, {
      ok: true,
      requestId,
      week_start_date: weekStart,
      plan: ai.plan,
      model: ai.model,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL
    });
  } catch (e) {
    const profile = {
      goal: String(body.goal || body.profileOverrides?.goal || "remise_en_forme"),
      level: String(body.level || body.profileOverrides?.level || "beginner")
    };
    const plan = fallbackPlan(profile);
    const info = normalizeGeminiError(e);
    return sendJson(res, 200, {
      ok: true,
      requestId,
      plan,
      fallback: true,
      error: info.message,
      error_code: info.code,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL
    });
  }
};
