"use strict";

const { createClient } = require("@supabase/supabase-js");
const {
  DEFAULT_MODEL,
  FALLBACK_MODEL,
  extractJson,
  callGeminiText,
  normalizeGeminiError
} = require("./_gemini");

const GEMINI_TIMEOUT_MS = 18000;

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type, authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

function sendJson(res, status, payload) {
  if (res.writableEnded) return;
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  if (!req.body) return {};
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch { return {}; }
  }
  return req.body;
}

function validateNutrition(raw) {
  if (!raw || typeof raw !== "object") return null;
  const nutrition = {
    calories: Math.round(Number(raw.calories)),
    protein: Math.round(Number(raw.protein)),
    carbs: Math.round(Number(raw.carbs)),
    fats: Math.round(Number(raw.fats)),
    notes: String(raw.notes || "").trim() || "Plan généré automatiquement."
  };
  if (!Number.isFinite(nutrition.calories) || nutrition.calories < 1200 || nutrition.calories > 4500) return null;
  if (!Number.isFinite(nutrition.protein) || nutrition.protein < 70 || nutrition.protein > 320) return null;
  if (!Number.isFinite(nutrition.carbs) || nutrition.carbs < 50 || nutrition.carbs > 550) return null;
  if (!Number.isFinite(nutrition.fats) || nutrition.fats < 30 || nutrition.fats > 180) return null;
  return nutrition;
}

function fallbackNutrition(weight = 75, goal = "maintenance", activity = "moderate") {
  const activityFactor = activity === "high" ? 34 : activity === "low" ? 28 : 31;
  const base = Math.round(weight * activityFactor);
  const normalizedGoal = String(goal || "maintenance").toLowerCase();
  const calories = normalizedGoal === "cut" || normalizedGoal === "perte_de_poids"
    ? base - 350
    : normalizedGoal === "bulk" || normalizedGoal === "prise_de_masse"
      ? base + 250
      : base;
  const protein = Math.round(weight * (normalizedGoal.includes("cut") || normalizedGoal.includes("perte") ? 2.1 : 1.8));
  const fats = Math.round(weight * 0.9);
  const carbs = Math.max(100, Math.round((calories - (protein * 4 + fats * 9)) / 4));
  return { calories, protein, carbs, fats, notes: "Plan nutrition de secours généré automatiquement." };
}

function buildPrompt(profile) {
  return `Tu es un nutritionniste sportif.
Génère des objectifs de macros en JSON strict.

RÈGLES:
- adapte au poids, à l'objectif et à l'activité
- donne calories, protéines, glucides, lipides
- ajoute une note courte pratique
- aucun markdown
- aucune phrase hors JSON

FORMAT UNIQUE:
{"calories":2400,"protein":160,"carbs":280,"fats":70,"notes":"..."}

PROFIL:
${JSON.stringify(profile)}`;
}

async function callGemini(apiKey, profile) {
  const result = await callGeminiText({
    apiKey,
    prompt: buildPrompt(profile),
    temperature: 0.35,
    maxOutputTokens: 500,
    timeoutMs: GEMINI_TIMEOUT_MS,
    retries: 1
  });
  const nutrition = validateNutrition(extractJson(result.text));
  if (!nutrition) throw new Error("INVALID_NUTRITION_JSON");
  return { nutrition, model: result.model };
}

async function loadProfile(supabase, userId) {
  const { data } = await supabase.from("profiles").select("weight").eq("id", userId).maybeSingle();
  return data || {};
}

module.exports = async function handler(req, res) {
  setCors(res);
  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;

  if (req.method === "OPTIONS") {
    res.statusCode = 204;
    return res.end();
  }
  if (req.method !== "POST") return sendJson(res, 405, { ok: false, error: "METHOD_NOT_ALLOWED", requestId });

  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return sendJson(res, 401, { ok: false, error: "UNAUTHORIZED", requestId });

  const { GEMINI_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) return sendJson(res, 500, { ok: false, error: "SERVER_MISCONFIG_SUPABASE", requestId });

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
  const auth = await supabase.auth.getUser(token);
  const userId = auth?.data?.user?.id;
  if (!userId) return sendJson(res, 401, { ok: false, error: "INVALID_TOKEN", requestId });

  const body = parseBody(req);

  try {
    const profile = await loadProfile(supabase, userId);
    const payload = {
      weight: Number(profile.weight || 75),
      goal: String(body.goal || "maintenance"),
      activity_level: String(body.activity_level || "moderate")
    };
    const result = GEMINI_API_KEY
      ? await callGemini(GEMINI_API_KEY, payload)
      : { nutrition: fallbackNutrition(payload.weight, payload.goal, payload.activity_level), model: "fallback:no-key" };

    const upsert = await supabase.from("nutrition_targets").upsert({
      user_id: userId,
      calories: result.nutrition.calories,
      protein: result.nutrition.protein,
      carbs: result.nutrition.carbs,
      fats: result.nutrition.fats,
      notes: result.nutrition.notes,
      updated_at: new Date().toISOString()
    }, { onConflict: "user_id" });
    if (upsert.error) throw upsert.error;

    return sendJson(res, 200, {
      ok: true,
      requestId,
      nutrition: result.nutrition,
      model: result.model,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL
    });
  } catch (e) {
    const fallback = fallbackNutrition(75, String(body.goal || "maintenance"), String(body.activity_level || "moderate"));
    const info = normalizeGeminiError(e);
    return sendJson(res, 200, {
      ok: true,
      requestId,
      nutrition: fallback,
      fallback: true,
      error: info.message,
      error_code: info.code,
      model_default: DEFAULT_MODEL,
      model_fallback: FALLBACK_MODEL
    });
  }
};
