-- ============================================================
-- FitAI Pro — MIGRATION v1.0 → v2.0
-- Exécuter UNIQUEMENT si vous avez déjà la v1 en production
-- ============================================================

-- 1. Ajouter colonnes manquantes à profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS age INTEGER;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS experience_years INTEGER DEFAULT 0;

-- 2. Ajouter colonnes à goals
ALTER TABLE public.goals ADD COLUMN IF NOT EXISTS equipment TEXT;
ALTER TABLE public.goals ADD COLUMN IF NOT EXISTS days_per_week INTEGER DEFAULT 3;

-- 3. Ajouter colonnes à workout_sessions
ALTER TABLE public.workout_sessions ADD COLUMN IF NOT EXISTS duration_actual_min INTEGER;
ALTER TABLE public.workout_sessions ADD COLUMN IF NOT EXISTS completed BOOLEAN DEFAULT false;
ALTER TABLE public.workout_sessions ADD COLUMN IF NOT EXISTS rating INTEGER CHECK (rating BETWEEN 1 AND 5);
ALTER TABLE public.workout_sessions ADD COLUMN IF NOT EXISTS notes TEXT;

-- 4. Ajouter colonnes à body_scans
ALTER TABLE public.body_scans ADD COLUMN IF NOT EXISTS physical_score NUMERIC;
ALTER TABLE public.body_scans ADD COLUMN IF NOT EXISTS extended_analysis JSONB;

-- 5. Ajouter colonnes à meals
ALTER TABLE public.meals ADD COLUMN IF NOT EXISTS meal_type TEXT DEFAULT 'other';

-- 6. Ajouter colonnes à community_posts
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS post_type TEXT DEFAULT 'text';
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS image_path TEXT;
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS workout_data JSONB;
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS transformation_data JSONB;
ALTER TABLE public.community_posts ADD COLUMN IF NOT EXISTS comment_count INTEGER DEFAULT 0;

-- 7. Créer table comments
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) <= 500),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Créer table kudos_log
CREATE TABLE IF NOT EXISTS public.kudos_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(post_id, user_id)
);

-- 9. Créer table user_streaks
CREATE TABLE IF NOT EXISTS public.user_streaks (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_activity_date DATE,
  total_workouts INTEGER DEFAULT 0,
  total_kudos_received INTEGER DEFAULT 0,
  total_kudos_given INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Indexes
CREATE INDEX IF NOT EXISTS idx_comments_post ON public.comments(post_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_user ON public.comments(user_id);
CREATE INDEX IF NOT EXISTS idx_kudos_log_post ON public.kudos_log(post_id);
CREATE INDEX IF NOT EXISTS idx_kudos_log_user ON public.kudos_log(user_id);
CREATE INDEX IF NOT EXISTS idx_user_streaks_streak ON public.user_streaks(current_streak DESC);
CREATE INDEX IF NOT EXISTS idx_community_posts_type ON public.community_posts(post_type, created_at DESC);

-- 11. RLS
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kudos_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_streaks ENABLE ROW LEVEL SECURITY;

-- Comments policies
DROP POLICY IF EXISTS "comments_select" ON public.comments;
CREATE POLICY "comments_select" ON public.comments FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "comments_insert" ON public.comments;
CREATE POLICY "comments_insert" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "comments_delete" ON public.comments;
CREATE POLICY "comments_delete" ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- Kudos_log policies
DROP POLICY IF EXISTS "kudos_select" ON public.kudos_log;
CREATE POLICY "kudos_select" ON public.kudos_log FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "kudos_insert" ON public.kudos_log;
CREATE POLICY "kudos_insert" ON public.kudos_log FOR INSERT WITH CHECK (auth.uid() = user_id);

-- User_streaks policies
DROP POLICY IF EXISTS "streaks_select" ON public.user_streaks;
CREATE POLICY "streaks_select" ON public.user_streaks FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "streaks_insert" ON public.user_streaks;
CREATE POLICY "streaks_insert" ON public.user_streaks FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "streaks_update" ON public.user_streaks;
CREATE POLICY "streaks_update" ON public.user_streaks FOR UPDATE USING (auth.uid() = user_id);

-- 12. Fonctions
CREATE OR REPLACE FUNCTION public.give_kudos(target_post_id UUID)
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  IF EXISTS (SELECT 1 FROM public.kudos_log WHERE post_id = target_post_id AND user_id = auth.uid()) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'already_kudosed');
  END IF;
  
  INSERT INTO public.kudos_log (post_id, user_id) VALUES (target_post_id, auth.uid());
  UPDATE public.community_posts SET kudos = kudos + 1 WHERE id = target_post_id;
  
  UPDATE public.user_streaks 
  SET total_kudos_received = total_kudos_received + 1, updated_at = NOW()
  WHERE user_id = (SELECT user_id FROM public.community_posts WHERE id = target_post_id);
  
  RETURN jsonb_build_object('ok', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.update_user_streak()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_streaks (user_id, current_streak, longest_streak, last_activity_date, total_workouts)
  VALUES (NEW.user_id, 1, 1, CURRENT_DATE, 1)
  ON CONFLICT (user_id) DO UPDATE SET
    current_streak = CASE 
      WHEN user_streaks.last_activity_date = CURRENT_DATE - 1 THEN user_streaks.current_streak + 1
      WHEN user_streaks.last_activity_date = CURRENT_DATE THEN user_streaks.current_streak
      ELSE 1
    END,
    longest_streak = GREATEST(
      user_streaks.longest_streak, 
      CASE 
        WHEN user_streaks.last_activity_date = CURRENT_DATE - 1 THEN user_streaks.current_streak + 1
        WHEN user_streaks.last_activity_date = CURRENT_DATE THEN user_streaks.current_streak
        ELSE 1
      END
    ),
    last_activity_date = CURRENT_DATE,
    total_workouts = user_streaks.total_workouts + 1,
    updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.update_comment_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.community_posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 13. Triggers
DROP TRIGGER IF EXISTS on_workout_saved ON public.workout_sessions;
CREATE TRIGGER on_workout_saved
  AFTER INSERT ON public.workout_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_user_streak();

DROP TRIGGER IF EXISTS on_comment_change ON public.comments;
CREATE TRIGGER on_comment_change
  AFTER INSERT OR DELETE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.update_comment_count();

-- 14. Initialiser streaks pour users existants
INSERT INTO public.user_streaks (user_id, current_streak, longest_streak, total_workouts)
SELECT 
  u.id,
  0,
  0,
  COALESCE((SELECT COUNT(*) FROM public.workout_sessions ws WHERE ws.user_id = u.id), 0)
FROM auth.users u
WHERE NOT EXISTS (SELECT 1 FROM public.user_streaks us WHERE us.user_id = u.id);

-- 15. Grants
GRANT EXECUTE ON FUNCTION public.give_kudos TO authenticated;

-- ============================================================
-- MIGRATION COMPLETE
-- ============================================================
