-- ============================================================
-- FitAI Pro v2.0.0 — SCHEMA SQL COMPLET
-- Inclut: Community améliorée, Streaks, Body Scan enrichi
-- Executer dans Supabase Dashboard → SQL Editor
-- ============================================================

-- ==================== TABLES DE BASE ====================

-- 1. PROFILES (PK = auth.users.id)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  avatar_url TEXT,
  weight INTEGER,
  height INTEGER,
  age INTEGER,
  experience_years INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. GOALS (one per user)
CREATE TABLE IF NOT EXISTS public.goals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT,
  level TEXT,
  text TEXT,
  constraints TEXT,
  equipment TEXT,
  days_per_week INTEGER DEFAULT 3,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT goals_user_unique UNIQUE (user_id)
);

-- 3. WORKOUT_SESSIONS
CREATE TABLE IF NOT EXISTS public.workout_sessions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan JSONB NOT NULL DEFAULT '{}',
  duration_actual_min INTEGER,
  completed BOOLEAN DEFAULT false,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. BODY_SCANS (enrichi v2)
CREATE TABLE IF NOT EXISTS public.body_scans (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  image_path TEXT NOT NULL,
  ai_feedback TEXT,
  ai_version TEXT,
  physical_score NUMERIC,
  symmetry_score NUMERIC,
  posture_score NUMERIC,
  bodyfat_proxy NUMERIC,
  extended_analysis JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. MEALS
CREATE TABLE IF NOT EXISTS public.meals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  calories INTEGER DEFAULT 0,
  protein INTEGER DEFAULT 0,
  carbs INTEGER DEFAULT 0,
  fat INTEGER DEFAULT 0,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  meal_type TEXT DEFAULT 'other', -- breakfast, lunch, dinner, snack, other
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. NUTRITION_TARGETS
CREATE TABLE IF NOT EXISTS public.nutrition_targets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  calories INTEGER,
  protein INTEGER,
  carbs INTEGER,
  fats INTEGER,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT nutrition_targets_user_unique UNIQUE (user_id)
);

-- ==================== COMMUNITY TABLES ====================

-- 7. COMMUNITY_POSTS (enrichi v2)
CREATE TABLE IF NOT EXISTS public.community_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) <= 2000),
  post_type TEXT DEFAULT 'text', -- text, workout, transformation, achievement
  image_path TEXT,
  workout_data JSONB,
  transformation_data JSONB,
  kudos INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. COMMENTS (nouveau)
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) <= 500),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. KUDOS_LOG (pour éviter double-kudos)
CREATE TABLE IF NOT EXISTS public.kudos_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.community_posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(post_id, user_id)
);

-- 10. USER_STREAKS
CREATE TABLE IF NOT EXISTS public.user_streaks (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_activity_date DATE,
  total_workouts INTEGER DEFAULT 0,
  total_kudos_received INTEGER DEFAULT 0,
  total_kudos_given INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. ACHIEVEMENTS
CREATE TABLE IF NOT EXISTS public.achievements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  earned_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, code)
);

-- 12. TRAINING_SCHEDULE
CREATE TABLE IF NOT EXISTS public.training_schedule (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  workout_type TEXT NOT NULL,
  intensity TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'planned',
  notes TEXT,
  week_start_date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);


-- ==================== INDEXES ====================

CREATE INDEX IF NOT EXISTS idx_profiles_updated ON public.profiles(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_goals_user ON public.goals(user_id);
CREATE INDEX IF NOT EXISTS idx_workout_sessions_user ON public.workout_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_workout_sessions_created ON public.workout_sessions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_body_scans_user ON public.body_scans(user_id);
CREATE INDEX IF NOT EXISTS idx_body_scans_created ON public.body_scans(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_meals_user_date ON public.meals(user_id, date);
CREATE INDEX IF NOT EXISTS idx_community_posts_created ON public.community_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_community_posts_user ON public.community_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_community_posts_type ON public.community_posts(post_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_post ON public.comments(post_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_user ON public.comments(user_id);
CREATE INDEX IF NOT EXISTS idx_kudos_log_post ON public.kudos_log(post_id);
CREATE INDEX IF NOT EXISTS idx_kudos_log_user ON public.kudos_log(user_id);
CREATE INDEX IF NOT EXISTS idx_nutrition_targets_user ON public.nutrition_targets(user_id);
CREATE INDEX IF NOT EXISTS idx_training_schedule_user_week ON public.training_schedule(user_id, week_start_date);
CREATE INDEX IF NOT EXISTS idx_user_streaks_streak ON public.user_streaks(current_streak DESC);


-- ==================== RLS POLICIES ====================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workout_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.body_scans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kudos_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nutrition_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;

-- PROFILES
DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_select_public" ON public.profiles;
CREATE POLICY "profiles_select_public" ON public.profiles FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- GOALS
DROP POLICY IF EXISTS "goals_select_own" ON public.goals;
CREATE POLICY "goals_select_own" ON public.goals FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "goals_insert_own" ON public.goals;
CREATE POLICY "goals_insert_own" ON public.goals FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "goals_update_own" ON public.goals;
CREATE POLICY "goals_update_own" ON public.goals FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- WORKOUT_SESSIONS
DROP POLICY IF EXISTS "ws_select_own" ON public.workout_sessions;
CREATE POLICY "ws_select_own" ON public.workout_sessions FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ws_insert_own" ON public.workout_sessions;
CREATE POLICY "ws_insert_own" ON public.workout_sessions FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "ws_update_own" ON public.workout_sessions;
CREATE POLICY "ws_update_own" ON public.workout_sessions FOR UPDATE USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ws_delete_own" ON public.workout_sessions;
CREATE POLICY "ws_delete_own" ON public.workout_sessions FOR DELETE USING (auth.uid() = user_id);

-- BODY_SCANS
DROP POLICY IF EXISTS "bs_select_own" ON public.body_scans;
CREATE POLICY "bs_select_own" ON public.body_scans FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "bs_insert_own" ON public.body_scans;
CREATE POLICY "bs_insert_own" ON public.body_scans FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "bs_update_own" ON public.body_scans;
CREATE POLICY "bs_update_own" ON public.body_scans FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- MEALS
DROP POLICY IF EXISTS "meals_select_own" ON public.meals;
CREATE POLICY "meals_select_own" ON public.meals FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "meals_insert_own" ON public.meals;
CREATE POLICY "meals_insert_own" ON public.meals FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "meals_update_own" ON public.meals;
CREATE POLICY "meals_update_own" ON public.meals FOR UPDATE USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "meals_delete_own" ON public.meals;
CREATE POLICY "meals_delete_own" ON public.meals FOR DELETE USING (auth.uid() = user_id);

-- COMMUNITY_POSTS
DROP POLICY IF EXISTS "cp_select_all" ON public.community_posts;
CREATE POLICY "cp_select_all" ON public.community_posts FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "cp_insert_own" ON public.community_posts;
CREATE POLICY "cp_insert_own" ON public.community_posts FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "cp_update_own" ON public.community_posts;
CREATE POLICY "cp_update_own" ON public.community_posts FOR UPDATE USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "cp_delete_own" ON public.community_posts;
CREATE POLICY "cp_delete_own" ON public.community_posts FOR DELETE USING (auth.uid() = user_id);

-- COMMENTS
DROP POLICY IF EXISTS "comments_select" ON public.comments;
CREATE POLICY "comments_select" ON public.comments FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "comments_insert" ON public.comments;
CREATE POLICY "comments_insert" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "comments_delete" ON public.comments;
CREATE POLICY "comments_delete" ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- KUDOS_LOG
DROP POLICY IF EXISTS "kudos_select" ON public.kudos_log;
CREATE POLICY "kudos_select" ON public.kudos_log FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "kudos_insert" ON public.kudos_log;
CREATE POLICY "kudos_insert" ON public.kudos_log FOR INSERT WITH CHECK (auth.uid() = user_id);

-- USER_STREAKS (anyone authenticated can see leaderboard)
DROP POLICY IF EXISTS "streaks_select" ON public.user_streaks;
CREATE POLICY "streaks_select" ON public.user_streaks FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS "streaks_insert" ON public.user_streaks;
CREATE POLICY "streaks_insert" ON public.user_streaks FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "streaks_update" ON public.user_streaks;
CREATE POLICY "streaks_update" ON public.user_streaks FOR UPDATE USING (auth.uid() = user_id);

-- ACHIEVEMENTS
DROP POLICY IF EXISTS "ach_select_own" ON public.achievements;
CREATE POLICY "ach_select_own" ON public.achievements FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ach_insert_own" ON public.achievements;
CREATE POLICY "ach_insert_own" ON public.achievements FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "ach_delete_own" ON public.achievements;
CREATE POLICY "ach_delete_own" ON public.achievements FOR DELETE USING (auth.uid() = user_id);

-- NUTRITION_TARGETS
DROP POLICY IF EXISTS "nt_select_own" ON public.nutrition_targets;
CREATE POLICY "nt_select_own" ON public.nutrition_targets FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "nt_insert_own" ON public.nutrition_targets;
CREATE POLICY "nt_insert_own" ON public.nutrition_targets FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "nt_update_own" ON public.nutrition_targets;
CREATE POLICY "nt_update_own" ON public.nutrition_targets FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- TRAINING_SCHEDULE
DROP POLICY IF EXISTS "ts_select_own" ON public.training_schedule;
CREATE POLICY "ts_select_own" ON public.training_schedule FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ts_insert_own" ON public.training_schedule;
CREATE POLICY "ts_insert_own" ON public.training_schedule FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "ts_delete_own" ON public.training_schedule;
CREATE POLICY "ts_delete_own" ON public.training_schedule FOR DELETE USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "ts_update_own" ON public.training_schedule;
CREATE POLICY "ts_update_own" ON public.training_schedule FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);


-- ==================== FUNCTIONS ====================

-- Fonction sécurisée pour donner un kudos (évite double-kudos)
CREATE OR REPLACE FUNCTION public.give_kudos(target_post_id UUID)
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  -- Check if already kudosed
  IF EXISTS (SELECT 1 FROM public.kudos_log WHERE post_id = target_post_id AND user_id = auth.uid()) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'already_kudosed');
  END IF;
  
  -- Log the kudos
  INSERT INTO public.kudos_log (post_id, user_id) VALUES (target_post_id, auth.uid());
  
  -- Increment kudos count
  UPDATE public.community_posts SET kudos = kudos + 1 WHERE id = target_post_id;
  
  -- Update streak stats for post owner
  UPDATE public.user_streaks 
  SET total_kudos_received = total_kudos_received + 1, updated_at = NOW()
  WHERE user_id = (SELECT user_id FROM public.community_posts WHERE id = target_post_id);
  
  RETURN jsonb_build_object('ok', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fonction pour mettre à jour les streaks
CREATE OR REPLACE FUNCTION public.update_user_streak()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_streaks (user_id, current_streak, longest_streak, last_activity_date, total_workouts)
  VALUES (NEW.user_id, 1, 1, CURRENT_DATE, 1)
  ON CONFLICT (user_id) DO UPDATE SET
    current_streak = CASE 
      WHEN user_streaks.last_activity_date = CURRENT_DATE - 1 THEN user_streaks.current_streak + 1
      WHEN user_streaks.last_activity_date = CURRENT_DATE THEN user_streaks.current_streak
      ELSE 1
    END,
    longest_streak = GREATEST(
      user_streaks.longest_streak, 
      CASE 
        WHEN user_streaks.last_activity_date = CURRENT_DATE - 1 THEN user_streaks.current_streak + 1
        WHEN user_streaks.last_activity_date = CURRENT_DATE THEN user_streaks.current_streak
        ELSE 1
      END
    ),
    last_activity_date = CURRENT_DATE,
    total_workouts = user_streaks.total_workouts + 1,
    updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger pour streak sur workout_sessions
DROP TRIGGER IF EXISTS on_workout_saved ON public.workout_sessions;
CREATE TRIGGER on_workout_saved
  AFTER INSERT ON public.workout_sessions
  FOR EACH ROW EXECUTE FUNCTION public.update_user_streak();

-- Fonction pour mettre à jour le compteur de commentaires
CREATE OR REPLACE FUNCTION public.update_comment_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.community_posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.community_posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_comment_change ON public.comments;
CREATE TRIGGER on_comment_change
  AFTER INSERT OR DELETE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.update_comment_count();

-- Auto-créer profil et streak à l'inscription
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, created_at, updated_at)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)), NOW(), NOW())
  ON CONFLICT (id) DO NOTHING;
  
  INSERT INTO public.user_streaks (user_id, current_streak, longest_streak, last_activity_date, total_workouts)
  VALUES (NEW.id, 0, 0, NULL, 0)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- ==================== STORAGE ====================

-- Storage policies for user_uploads bucket
DROP POLICY IF EXISTS "user_uploads_insert" ON storage.objects;
CREATE POLICY "user_uploads_insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'user_uploads' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "user_uploads_select" ON storage.objects;
CREATE POLICY "user_uploads_select" ON storage.objects FOR SELECT
  USING (bucket_id = 'user_uploads' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "user_uploads_delete" ON storage.objects;
CREATE POLICY "user_uploads_delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'user_uploads' AND (storage.foldername(name))[1] = auth.uid()::text);


-- ==================== GRANTS ====================

GRANT EXECUTE ON FUNCTION public.give_kudos TO authenticated;


-- ============================================================
-- DONE. Schema v2.0 created with community features.
-- ============================================================
