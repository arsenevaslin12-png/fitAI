# FitAI Pro v2.1 (cleaned exam build)

Application de coaching fitness alimentée par l'IA.

## Ce qui a été corrigé dans ce package

- dépôt nettoyé (suppression des faux fichiers racine et des anciennes archives ZIP embarquées)
- `env.example` remplacé par un vrai template d'environnement
- `supabase/schema.sql` rendu cohérent avec l'application actuelle
- corrections de cohérence côté frontend :
  - navigation Dashboard → Scan IA réparée
  - statistiques de progression/streak harmonisées
  - carte “Entraînement du jour” alimentée par les vraies données
  - affichage des photos de Body Scan réparé via signed URLs
- script de vérification syntaxique ajouté (`npm run verify`)

## Stack

- Frontend: Vanilla JS / HTML / CSS
- Backend: Vercel Serverless Functions
- DB/Auth/Storage: Supabase
- AI: Google Gemini

## Installation recommandée

### 1. Déploiement
```bash
npm install
npm run verify
vercel deploy
```

### 2. Base de données Supabase

Exécutez **`supabase/schema.sql`** dans le SQL Editor.

Le fichier `schema.sql` inclut maintenant :
- tables principales
- tables sociales (`friendships`, `comments`)
- streaks
- daily moods
- fonction RPC `give_kudos`
- colonnes Body Scan utilisées par le frontend actuel

Les fichiers `migration_v*.sql` sont conservés comme historique/patchs pour des bases déjà existantes.

### 3. Storage
Créez le bucket privé `user_uploads`.

### 4. Variables d'environnement Vercel

Variables minimales :
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY` **ou** `SUPABASE_ANON_KEY`

Variables IA :
- `GEMINI_API_KEY`
- `GEMINI_MODEL` (optionnel)

Variables optionnelles :
- `ALLOWED_ORIGIN`
- `BUCKET`
- `LOG_LEVEL`

## Vérifications utiles

```bash
npm run verify
```

## Structure

```text
api/
public/
lib/
scripts/
supabase/
vercel.json
package.json
```

## Notes

- Le frontend reste volontairement inchangé visuellement.
- Cette version corrige surtout la cohérence fonctionnelle, la structure du dépôt et la reproductibilité.
