# Changes applied

## Repository cleanup
- Removed corrupted root files that did not match their names.
- Removed bundled historical ZIP archives from the project root.
- Replaced `env.example` with a real environment template.
- Added `scripts/check-syntax.js` and wired `npm run verify`.

## Functional fixes (without redesigning the UI)
- Fixed broken Dashboard links that pointed to `scan` instead of `bodyscan`.
- Replaced the fake Dashboard workout placeholder with real session-driven content.
- Unified streak / session metrics so Dashboard, Progress and Défis no longer read different shapes of streak data.
- Added signed URL resolution for Body Scan images so completed scans can display their photos again.
- Cleared local caches after saving sessions or scans to reduce stale stats.

## Backend / config
- `_env.js` now accepts either a legacy anon JWT or a Supabase publishable key.
- Gemini is no longer treated as a hard blocker at config-validation level, which allows graceful fallbacks.

## Database
- `supabase/schema.sql` was rewritten as an idempotent complete schema aligned with the current frontend:
  - age in profiles
  - physical_score and extended_analysis in body_scans
  - friendships, comments, user_streaks, daily_moods
  - give_kudos RPC
  - streak columns consolidated
