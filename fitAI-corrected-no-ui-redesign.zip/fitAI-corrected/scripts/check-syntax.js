"use strict";

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const ROOT = process.cwd();
const TARGET_DIRS = ["api", "public", "lib", "scripts"];

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (entry.isFile() && full.endsWith(".js")) out.push(full);
  }
  return out;
}

const files = TARGET_DIRS.flatMap((d) => walk(path.join(ROOT, d)));
let failed = false;

for (const file of files) {
  const result = spawnSync(process.execPath, ["--check", file], { stdio: "pipe", encoding: "utf-8" });
  if (result.status !== 0) {
    failed = true;
    process.stderr.write(`\n[syntax] ${file}\n${result.stderr || result.stdout}\n`);
  }
}

if (failed) process.exit(1);
console.log(`Syntax OK on ${files.length} file(s).`);
